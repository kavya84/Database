#!/usr/bin/env python
# coding: utf-8

# In[ ]:


import pandas as pd # importing packages
import mysql.connector as mysql # import mysql packages 


dbconn = mysql.connect(host = "academicmysql.mysql.database.azure.com",user = "kxg3373",password = "Kavya@Sri123",database = "kxg3373") #read csv
cursor = dbconn.cursor()   # cursor 
cursor.execute("select database()")   # select database
record = cursor.fetchone()  # record fetched 
print("connectd", record)  #connected successfully!!
#STATE()
def  state():
    data_read = pd.read_csv('/Users/kavyasrigarikipati/Downloads/005_Project1_Data/US_state.csv',delimiter = ',')   #read csv
    data_read.head()  # using head function
    for i,row in data_read.iterrows():  # using for loop to iterate 
        query = "INSERT INTO STATE VALUES(%s,%s,%s,%s,%s,%s,%s,%s,%s,%s)"  #query to insert
        cursor.execute(query,tuple(row))  # executing the query 
        print("record inserted") # record inserted 
    cursor.close()  #closing 
    dbconn.commit() #commit
    dbconn.close    #closing connection 

#COUNTY()
def county():
    data_read = pd.read_csv('/Users/kavyasrigarikipati/Downloads/005_Project1_Data/Us_County.csv',delimiter = ',') #read csv
    data_read.head() # using head function
    for i,row in data_read.iterrows():   # using for loop to iterate 
        query = "INSERT INTO COUNTY VALUES(%s,%s,%s,%s,%s)"  #query to insert
        cursor.execute(query,tuple(row)) # executing the query 
        print("record inserted")# record inserted 
    cursor.close()  #closing 
    dbconn.commit() #commit
    dbconn.close #closing connection 

#CONFIRMED_CASES()
def confirmedcases():
    data_read = pd.read_csv('/Users/kavyasrigarikipati/Downloads/005_Project1_Data/Us_confirmed_cases.csv',delimiter = ',') #read csv
    data_read.head()  # using head function
    for i,row in data_read.iterrows():   # using for loop to iterate 
        query = "INSERT INTO CONFIRMED_CASES VALUES(%s,%s,%s,%s)"   #query to insert
        cursor.execute(query,tuple(row))  # executing the query 
        print("record inserted")  # record inserted
    cursor.close() #closing 
    dbconn.commit() #commit
    dbconn.close  #closing connection 

#DEATHS()
def deaths():
    data_read = pd.read_csv('/Users/kavyasrigarikipati/Downloads/005_Project1_Data/Us_deaths.csv',delimiter = ',') #read csv
    data_read.head() # using head function
    for i,row in data_read.iterrows():  # using for loop to iterate 
        query = "INSERT INTO DEATHS VALUES(%s,%s,%s,%s)"  #query to insert
        cursor.execute(query,tuple(row))  # executing the query 
        print("record inserted")  # record inserted
    cursor.close()  #closing 
    dbconn.commit() #commit
    dbconn.close #closing connection 

#VACCINATIONS()
def vaccinations():
    data_read = pd.read_csv('/Users/kavyasrigarikipati/Downloads/005_Project1_Data/US_Vaccination.csv',delimiter = ',') #read csv
    data_read.head() # using head function
    for i,row in data_read.iterrows():   # using for loop to iterate 
        query = "INSERT INTO VACCINATIONS VALUES(%s,%s,%s,%s,%s,%s,%s,%s,%s)"  #query to insert
        cursor.execute(query,tuple(row))  # executing the query 
        print("record inserted")  # record inserted
    cursor.close()   #closing 
    dbconn.commit() #commit
    dbconn.close  #closing connection 

